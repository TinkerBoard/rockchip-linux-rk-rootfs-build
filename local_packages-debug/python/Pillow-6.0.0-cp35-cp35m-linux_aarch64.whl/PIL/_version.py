# Master version for Pillow
__version__ = '6.0.0'
