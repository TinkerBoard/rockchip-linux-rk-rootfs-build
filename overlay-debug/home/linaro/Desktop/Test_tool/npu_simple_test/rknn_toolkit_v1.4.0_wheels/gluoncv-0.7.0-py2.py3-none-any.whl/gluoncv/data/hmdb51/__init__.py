# pylint: disable=wildcard-import
"""Video action recognition, HMDB51 dataset.
http://serre-lab.clps.brown.edu/resource/hmdb-a-large-human-motion-database/
"""
from __future__ import absolute_import
from .classification import *
