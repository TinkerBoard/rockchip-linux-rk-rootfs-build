"""tracking dataset,include youtube-bb,VID,DET,COCO dataset"""
from __future__ import absolute_import
from .track import *
