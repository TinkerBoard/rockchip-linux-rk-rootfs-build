"""Alpha pose for real time human pose estimation"""
# pylint: disable=wildcard-import
from .fast_pose import *
