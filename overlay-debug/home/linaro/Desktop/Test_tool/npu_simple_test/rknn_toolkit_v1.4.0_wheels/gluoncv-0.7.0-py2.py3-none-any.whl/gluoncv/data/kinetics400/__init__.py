# pylint: disable=wildcard-import
"""Video action recognition, Kinetics400 dataset.
https://deepmind.com/research/open-source/open-source-datasets/kinetics/
"""
from __future__ import absolute_import
from .classification import *
