"""Datasets from RecordIO files."""
